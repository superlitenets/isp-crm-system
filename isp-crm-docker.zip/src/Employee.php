<?php

namespace App;

class Employee {
    private \PDO $db;

    public function __construct(?\PDO $db = null) {
        $this->db = $db ?? \Database::getConnection();
    }
    
    public function getEmployees(): array {
        $stmt = $this->db->query("
            SELECT e.*, d.name as department_name,
                   SPLIT_PART(e.name, ' ', 1) as first_name,
                   CASE 
                       WHEN POSITION(' ' IN e.name) > 0 
                       THEN SUBSTRING(e.name FROM POSITION(' ' IN e.name) + 1)
                       ELSE ''
                   END as last_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.employment_status = 'active'
            ORDER BY e.name ASC
        ");
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function generateEmployeeId(): string {
        return 'EMP-' . date('Y') . '-' . str_pad(random_int(1, 9999), 4, '0', STR_PAD_LEFT);
    }

    public function createUserAccount(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO users (name, email, phone, password_hash, role)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $data['name'],
            $data['email'],
            $data['phone'],
            password_hash($data['password'], PASSWORD_DEFAULT),
            $data['role'] ?? 'technician'
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function create(array $data): int {
        $userId = null;
        
        if (isset($data['user_id']) && $data['user_id'] === 'create_new') {
            if (!empty($data['new_user_email']) && !empty($data['new_user_password'])) {
                $userId = $this->createUserAccount([
                    'name' => $data['name'],
                    'email' => $data['new_user_email'],
                    'phone' => $data['phone'],
                    'password' => $data['new_user_password'],
                    'role' => $data['new_user_role'] ?? 'technician'
                ]);
            }
        } elseif (!empty($data['user_id'])) {
            $userId = (int)$data['user_id'];
        }
        
        $stmt = $this->db->prepare("
            INSERT INTO employees (employee_id, user_id, name, email, phone, department_id, position, salary, hire_date, employment_status, emergency_contact, emergency_phone, address, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $data['employee_id'] ?? $this->generateEmployeeId(),
            $userId,
            $data['name'],
            $data['email'],
            $data['phone'],
            $data['department_id'] ?: null,
            $data['position'],
            $data['salary'] ?: null,
            $data['hire_date'] ?: null,
            $data['employment_status'] ?? 'active',
            $data['emergency_contact'] ?? null,
            $data['emergency_phone'] ?? null,
            $data['address'] ?? null,
            $data['notes'] ?? null
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): bool {
        $fields = [];
        $values = [];
        
        $allowedFields = ['name', 'email', 'phone', 'department_id', 'position', 'salary', 'hire_date', 'employment_status', 'emergency_contact', 'emergency_phone', 'address', 'notes', 'user_id'];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                if ($field === 'user_id' && $data[$field] === 'create_new') {
                    continue;
                }
                $fields[] = "$field = ?";
                $value = $data[$field] === '' ? null : $data[$field];
                if ($field === 'user_id' && $value !== null) {
                    $value = (int)$value;
                }
                $values[] = $value;
            }
        }
        
        if (empty($fields)) {
            return false;
        }
        
        $fields[] = "updated_at = CURRENT_TIMESTAMP";
        $values[] = $id;
        
        $stmt = $this->db->prepare("UPDATE employees SET " . implode(', ', $fields) . " WHERE id = ?");
        return $stmt->execute($values);
    }

    public function delete(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM employees WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function find(int $id): ?array {
        $stmt = $this->db->prepare("
            SELECT e.*, d.name as department_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE e.id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public function getAll(string $search = '', ?int $departmentId = null, int $limit = 50, int $offset = 0): array {
        $sql = "
            SELECT e.*, d.name as department_name
            FROM employees e
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE 1=1
        ";
        $params = [];
        
        if ($search) {
            $sql .= " AND (e.name ILIKE ? OR e.employee_id ILIKE ? OR e.email ILIKE ? OR e.phone ILIKE ? OR e.position ILIKE ?)";
            $searchTerm = "%$search%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }
        
        if ($departmentId) {
            $sql .= " AND e.department_id = ?";
            $params[] = $departmentId;
        }
        
        $sql .= " ORDER BY e.name ASC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function count(string $search = '', ?int $departmentId = null): int {
        $sql = "SELECT COUNT(*) FROM employees e WHERE 1=1";
        $params = [];
        
        if ($search) {
            $sql .= " AND (e.name ILIKE ? OR e.employee_id ILIKE ? OR e.email ILIKE ? OR e.phone ILIKE ?)";
            $searchTerm = "%$search%";
            $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        }
        
        if ($departmentId) {
            $sql .= " AND e.department_id = ?";
            $params[] = $departmentId;
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int) $stmt->fetchColumn();
    }

    public function getStats(): array {
        $stmt = $this->db->query("
            SELECT 
                COUNT(*) as total,
                COUNT(*) FILTER (WHERE employment_status = 'active') as active,
                COUNT(*) FILTER (WHERE employment_status = 'on_leave') as on_leave,
                COUNT(*) FILTER (WHERE employment_status = 'terminated') as terminated,
                COUNT(DISTINCT department_id) as departments
            FROM employees
        ");
        return $stmt->fetch();
    }

    public function getEmploymentStatuses(): array {
        return [
            'active' => 'Active',
            'probation' => 'Probation',
            'on_leave' => 'On Leave',
            'suspended' => 'Suspended',
            'terminated' => 'Terminated'
        ];
    }

    public function createDepartment(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO departments (name, description, manager_id)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([
            $data['name'],
            $data['description'] ?? null,
            $data['manager_id'] ?: null
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function updateDepartment(int $id, array $data): bool {
        $stmt = $this->db->prepare("
            UPDATE departments SET name = ?, description = ?, manager_id = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        return $stmt->execute([
            $data['name'],
            $data['description'] ?? null,
            $data['manager_id'] ?: null,
            $id
        ]);
    }

    public function deleteDepartment(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM departments WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getDepartment(int $id): ?array {
        $stmt = $this->db->prepare("
            SELECT d.*, e.name as manager_name
            FROM departments d
            LEFT JOIN employees e ON d.manager_id = e.id
            WHERE d.id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public function getAllDepartments(): array {
        $stmt = $this->db->query("
            SELECT d.*, e.name as manager_name,
                   (SELECT COUNT(*) FROM employees WHERE department_id = d.id) as employee_count
            FROM departments d
            LEFT JOIN employees e ON d.manager_id = e.id
            ORDER BY d.name ASC
        ");
        return $stmt->fetchAll();
    }

    public function linkToUser(int $employeeId, int $userId): bool {
        $stmt = $this->db->prepare("UPDATE employees SET user_id = ? WHERE id = ?");
        return $stmt->execute([$userId, $employeeId]);
    }

    public function getByUserId(int $userId): ?array {
        $stmt = $this->db->prepare("SELECT * FROM employees WHERE user_id = ?");
        $stmt->execute([$userId]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public function getTechnicians(): array {
        $stmt = $this->db->query("
            SELECT e.*, u.id as user_id, u.email as user_email
            FROM employees e
            LEFT JOIN users u ON e.user_id = u.id
            WHERE e.employment_status = 'active'
            ORDER BY e.name ASC
        ");
        return $stmt->fetchAll();
    }

    public function recordAttendance(array $data): int {
        $clockIn = $data['clock_in'] ?? null;
        $clockOut = $data['clock_out'] ?? null;
        $hoursWorked = null;
        $overtimeHours = 0;

        if ($clockIn && $clockOut) {
            $start = new \DateTime($clockIn);
            $end = new \DateTime($clockOut);
            $diff = $start->diff($end);
            $hoursWorked = $diff->h + ($diff->i / 60);
            if ($hoursWorked > 8) {
                $overtimeHours = $hoursWorked - 8;
            }
        }

        $stmt = $this->db->prepare("
            INSERT INTO attendance (employee_id, date, clock_in, clock_out, status, hours_worked, overtime_hours, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (employee_id, date) DO UPDATE SET
                clock_in = EXCLUDED.clock_in,
                clock_out = EXCLUDED.clock_out,
                status = EXCLUDED.status,
                hours_worked = EXCLUDED.hours_worked,
                overtime_hours = EXCLUDED.overtime_hours,
                notes = EXCLUDED.notes,
                updated_at = CURRENT_TIMESTAMP
        ");
        
        $stmt->execute([
            $data['employee_id'],
            $data['date'],
            $clockIn,
            $clockOut,
            $data['status'] ?? 'present',
            $hoursWorked,
            $overtimeHours,
            $data['notes'] ?? null
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function updateAttendance(int $id, array $data): bool {
        $clockIn = $data['clock_in'] ?? null;
        $clockOut = $data['clock_out'] ?? null;
        $hoursWorked = null;
        $overtimeHours = 0;

        if ($clockIn && $clockOut) {
            $start = new \DateTime($clockIn);
            $end = new \DateTime($clockOut);
            $diff = $start->diff($end);
            $hoursWorked = $diff->h + ($diff->i / 60);
            if ($hoursWorked > 8) {
                $overtimeHours = $hoursWorked - 8;
            }
        }

        $stmt = $this->db->prepare("
            UPDATE attendance SET 
                clock_in = ?, clock_out = ?, status = ?, hours_worked = ?, overtime_hours = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        return $stmt->execute([$clockIn, $clockOut, $data['status'], $hoursWorked, $overtimeHours, $data['notes'] ?? null, $id]);
    }

    public function deleteAttendance(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM attendance WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getAttendance(int $employeeId, ?string $startDate = null, ?string $endDate = null): array {
        $sql = "SELECT a.*, e.name as employee_name FROM attendance a 
                JOIN employees e ON a.employee_id = e.id 
                WHERE a.employee_id = ?";
        $params = [$employeeId];

        if ($startDate) {
            $sql .= " AND a.date >= ?";
            $params[] = $startDate;
        }
        if ($endDate) {
            $sql .= " AND a.date <= ?";
            $params[] = $endDate;
        }

        $sql .= " ORDER BY a.date DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getAllAttendance(string $date): array {
        $stmt = $this->db->prepare("
            SELECT a.*, e.name as employee_name, e.employee_id as emp_code, d.name as department_name
            FROM attendance a
            JOIN employees e ON a.employee_id = e.id
            LEFT JOIN departments d ON e.department_id = d.id
            WHERE a.date = ?
            ORDER BY e.name ASC
        ");
        $stmt->execute([$date]);
        return $stmt->fetchAll();
    }

    public function getTodayAttendance(): array {
        return $this->getAllAttendance(date('Y-m-d'));
    }

    public function getAttendanceStatuses(): array {
        return [
            'present' => 'Present',
            'absent' => 'Absent',
            'late' => 'Late',
            'half_day' => 'Half Day',
            'leave' => 'On Leave',
            'holiday' => 'Holiday',
            'work_from_home' => 'Work From Home'
        ];
    }

    public function getAttendanceStats(string $month): array {
        $startDate = $month . '-01';
        $endDate = date('Y-m-t', strtotime($startDate));

        $stmt = $this->db->prepare("
            SELECT 
                COUNT(*) FILTER (WHERE status = 'present') as present,
                COUNT(*) FILTER (WHERE status = 'absent') as absent,
                COUNT(*) FILTER (WHERE status = 'late') as late,
                COUNT(*) FILTER (WHERE status = 'leave') as on_leave,
                COUNT(*) FILTER (WHERE status = 'work_from_home') as wfh,
                SUM(COALESCE(hours_worked, 0)) as total_hours,
                SUM(COALESCE(overtime_hours, 0)) as total_overtime
            FROM attendance
            WHERE date >= ? AND date <= ?
        ");
        $stmt->execute([$startDate, $endDate]);
        return $stmt->fetch();
    }

    public function createPayroll(array $data): int {
        $baseSalary = (float)($data['base_salary'] ?? 0);
        $overtimePay = (float)($data['overtime_pay'] ?? 0);
        $bonuses = (float)($data['bonuses'] ?? 0);
        $deductions = (float)($data['deductions'] ?? 0);
        $tax = (float)($data['tax'] ?? 0);
        $netPay = $baseSalary + $overtimePay + $bonuses - $deductions - $tax;

        $stmt = $this->db->prepare("
            INSERT INTO payroll (employee_id, pay_period_start, pay_period_end, base_salary, overtime_pay, bonuses, deductions, tax, net_pay, status, payment_date, payment_method, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $data['employee_id'],
            $data['pay_period_start'],
            $data['pay_period_end'],
            $baseSalary,
            $overtimePay,
            $bonuses,
            $deductions,
            $tax,
            $netPay,
            $data['status'] ?? 'pending',
            $data['payment_date'] ?: null,
            $data['payment_method'] ?? null,
            $data['notes'] ?? null
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function updatePayroll(int $id, array $data): bool {
        $baseSalary = (float)($data['base_salary'] ?? 0);
        $overtimePay = (float)($data['overtime_pay'] ?? 0);
        $bonuses = (float)($data['bonuses'] ?? 0);
        $deductions = (float)($data['deductions'] ?? 0);
        $tax = (float)($data['tax'] ?? 0);
        $netPay = $baseSalary + $overtimePay + $bonuses - $deductions - $tax;

        $stmt = $this->db->prepare("
            UPDATE payroll SET 
                base_salary = ?, overtime_pay = ?, bonuses = ?, deductions = ?, tax = ?, net_pay = ?,
                status = ?, payment_date = ?, payment_method = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        return $stmt->execute([
            $baseSalary, $overtimePay, $bonuses, $deductions, $tax, $netPay,
            $data['status'], $data['payment_date'] ?: null, $data['payment_method'] ?? null, $data['notes'] ?? null, $id
        ]);
    }

    public function deletePayroll(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM payroll WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getPayroll(int $employeeId): array {
        $stmt = $this->db->prepare("
            SELECT p.*, e.name as employee_name
            FROM payroll p
            JOIN employees e ON p.employee_id = e.id
            WHERE p.employee_id = ?
            ORDER BY p.pay_period_end DESC
        ");
        $stmt->execute([$employeeId]);
        return $stmt->fetchAll();
    }

    public function getAllPayroll(?string $status = null, ?string $month = null): array {
        $sql = "SELECT p.*, e.name as employee_name, e.employee_id as emp_code, d.name as department_name
                FROM payroll p
                JOIN employees e ON p.employee_id = e.id
                LEFT JOIN departments d ON e.department_id = d.id
                WHERE 1=1";
        $params = [];

        if ($status) {
            $sql .= " AND p.status = ?";
            $params[] = $status;
        }

        if ($month) {
            $sql .= " AND p.pay_period_start <= ? AND p.pay_period_end >= ?";
            $monthStart = $month . '-01';
            $monthEnd = date('Y-m-t', strtotime($monthStart));
            $params[] = $monthEnd;
            $params[] = $monthStart;
        }

        $sql .= " ORDER BY p.pay_period_end DESC, e.name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getPayrollStatuses(): array {
        return [
            'pending' => 'Pending',
            'processing' => 'Processing',
            'paid' => 'Paid',
            'cancelled' => 'Cancelled'
        ];
    }

    public function getPaymentMethods(): array {
        return [
            'bank_transfer' => 'Bank Transfer',
            'check' => 'Check',
            'cash' => 'Cash',
            'mobile_money' => 'Mobile Money'
        ];
    }

    public function getPayrollStats(?string $month = null): array {
        $sql = "SELECT 
                    COUNT(*) as total_records,
                    COUNT(*) FILTER (WHERE status = 'pending') as pending,
                    COUNT(*) FILTER (WHERE status = 'paid') as paid,
                    SUM(CASE WHEN status = 'paid' THEN net_pay ELSE 0 END) as total_paid,
                    SUM(CASE WHEN status = 'pending' THEN net_pay ELSE 0 END) as total_pending
                FROM payroll";
        $params = [];

        if ($month) {
            $sql .= " WHERE pay_period_start >= ? AND pay_period_end <= ?";
            $monthStart = $month . '-01';
            $monthEnd = date('Y-m-t', strtotime($monthStart));
            $params = [$monthStart, $monthEnd];
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    public function createPerformanceReview(array $data): int {
        $stmt = $this->db->prepare("
            INSERT INTO performance_reviews (
                employee_id, reviewer_id, review_period_start, review_period_end,
                overall_rating, productivity_rating, quality_rating, teamwork_rating, communication_rating,
                goals_achieved, strengths, areas_for_improvement, goals_next_period, comments, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $data['employee_id'],
            $data['reviewer_id'] ?: null,
            $data['review_period_start'],
            $data['review_period_end'],
            $data['overall_rating'] ?: null,
            $data['productivity_rating'] ?: null,
            $data['quality_rating'] ?: null,
            $data['teamwork_rating'] ?: null,
            $data['communication_rating'] ?: null,
            $data['goals_achieved'] ?? null,
            $data['strengths'] ?? null,
            $data['areas_for_improvement'] ?? null,
            $data['goals_next_period'] ?? null,
            $data['comments'] ?? null,
            $data['status'] ?? 'draft'
        ]);

        return (int) $this->db->lastInsertId();
    }

    public function updatePerformanceReview(int $id, array $data): bool {
        $stmt = $this->db->prepare("
            UPDATE performance_reviews SET 
                reviewer_id = ?, overall_rating = ?, productivity_rating = ?, quality_rating = ?,
                teamwork_rating = ?, communication_rating = ?, goals_achieved = ?, strengths = ?,
                areas_for_improvement = ?, goals_next_period = ?, comments = ?, status = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        return $stmt->execute([
            $data['reviewer_id'] ?: null,
            $data['overall_rating'] ?: null,
            $data['productivity_rating'] ?: null,
            $data['quality_rating'] ?: null,
            $data['teamwork_rating'] ?: null,
            $data['communication_rating'] ?: null,
            $data['goals_achieved'] ?? null,
            $data['strengths'] ?? null,
            $data['areas_for_improvement'] ?? null,
            $data['goals_next_period'] ?? null,
            $data['comments'] ?? null,
            $data['status'],
            $id
        ]);
    }

    public function deletePerformanceReview(int $id): bool {
        $stmt = $this->db->prepare("DELETE FROM performance_reviews WHERE id = ?");
        return $stmt->execute([$id]);
    }

    public function getPerformanceReview(int $id): ?array {
        $stmt = $this->db->prepare("
            SELECT pr.*, e.name as employee_name, r.name as reviewer_name
            FROM performance_reviews pr
            JOIN employees e ON pr.employee_id = e.id
            LEFT JOIN employees r ON pr.reviewer_id = r.id
            WHERE pr.id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    public function getEmployeePerformanceReviews(int $employeeId): array {
        $stmt = $this->db->prepare("
            SELECT pr.*, e.name as employee_name, r.name as reviewer_name
            FROM performance_reviews pr
            JOIN employees e ON pr.employee_id = e.id
            LEFT JOIN employees r ON pr.reviewer_id = r.id
            WHERE pr.employee_id = ?
            ORDER BY pr.review_period_end DESC
        ");
        $stmt->execute([$employeeId]);
        return $stmt->fetchAll();
    }

    public function getAllPerformanceReviews(?string $status = null): array {
        $sql = "SELECT pr.*, e.name as employee_name, e.employee_id as emp_code, r.name as reviewer_name, d.name as department_name
                FROM performance_reviews pr
                JOIN employees e ON pr.employee_id = e.id
                LEFT JOIN employees r ON pr.reviewer_id = r.id
                LEFT JOIN departments d ON e.department_id = d.id
                WHERE 1=1";
        $params = [];

        if ($status) {
            $sql .= " AND pr.status = ?";
            $params[] = $status;
        }

        $sql .= " ORDER BY pr.review_period_end DESC, e.name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getPerformanceStatuses(): array {
        return [
            'draft' => 'Draft',
            'pending_review' => 'Pending Review',
            'in_progress' => 'In Progress',
            'completed' => 'Completed',
            'acknowledged' => 'Acknowledged'
        ];
    }

    public function getPerformanceStats(): array {
        $stmt = $this->db->query("
            SELECT 
                COUNT(*) as total_reviews,
                COUNT(*) FILTER (WHERE status = 'completed' OR status = 'acknowledged') as completed,
                COUNT(*) FILTER (WHERE status = 'draft' OR status = 'pending_review' OR status = 'in_progress') as pending,
                AVG(overall_rating) FILTER (WHERE overall_rating IS NOT NULL) as avg_rating
            FROM performance_reviews
        ");
        return $stmt->fetch();
    }
}
